# Mutunga's Workshop — Netlify deployment

This version is adapted for Netlify Functions.

## Important
The current SQLite database is stored in `/tmp` on Netlify. This is suitable for testing the deployment, but it is **not persistent production storage**. Customer accounts, inquiries, settings, and uploaded images can be lost when a function environment is replaced.

For a permanent live site, connect the app to a hosted database/storage service after confirming the Netlify deployment works.

## Netlify
1. Push this folder to GitHub.
2. In Netlify, choose Add new project > Import an existing project.
3. Select the GitHub repository.
4. Build command: `npm run netlify-build`
5. Publish directory: `public`
6. Node version is set to 22 in `netlify.toml`.
