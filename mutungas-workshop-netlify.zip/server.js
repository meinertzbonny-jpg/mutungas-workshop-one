const express = require("express");
const session = require("express-session");
const bcrypt = require("bcryptjs");
const Database = require("better-sqlite3");
const multer = require("multer");
const path = require("path");
const fs = require("fs");

const app = express();
const PORT = process.env.PORT || 3000;
const dbPath = process.env.NETLIFY ? "/tmp/mutungas.db" : "mutungas.db";
const db = new Database(dbPath);

fs.mkdirSync(path.join(__dirname, "public", "uploads"), { recursive: true });

app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(session({
  secret: process.env.SESSION_SECRET || "change-this-secret-before-production",
  resave: false,
  saveUninitialized: false,
  cookie: { httpOnly: true, sameSite: "lax" }
}));
app.use(express.static(path.join(__dirname, "public")));

db.exec(`
CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  email TEXT UNIQUE NOT NULL,
  password_hash TEXT NOT NULL,
  role TEXT NOT NULL DEFAULT 'customer',
  created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS products (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  category TEXT NOT NULL,
  name TEXT NOT NULL,
  description TEXT DEFAULT '',
  price TEXT DEFAULT '',
  image TEXT DEFAULT '',
  available INTEGER DEFAULT 1,
  created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS services (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  description TEXT DEFAULT '',
  price TEXT DEFAULT '',
  image TEXT DEFAULT '',
  created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS inquiries (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL,
  product_id INTEGER,
  service_id INTEGER,
  message TEXT NOT NULL,
  reply TEXT DEFAULT '',
  status TEXT DEFAULT 'new',
  created_at TEXT DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY(user_id) REFERENCES users(id),
  FOREIGN KEY(product_id) REFERENCES products(id),
  FOREIGN KEY(service_id) REFERENCES services(id)
);
CREATE TABLE IF NOT EXISTS settings (
  key TEXT PRIMARY KEY,
  value TEXT NOT NULL
);
`);

const settingDefaults = {
  business_name: "Mutunga's Workshop",
  owner_name: "Jospat Mutunga",
  about: "I am Jospat Mutunga from Kwale County. Mutunga's Workshop provides furniture, agricultural products and engineering/repair services.",
  location: "Msambweni, Kwale County, Kenya",
  phone: "YOUR PHONE NUMBER",
  whatsapp: "YOUR WHATSAPP NUMBER",
  email: "YOUR EMAIL",
  hours: "Monday - Saturday: 8:00 AM - 6:00 PM",
  reach_me: "Visit the workshop or contact me by phone or WhatsApp."
};
for (const [key, value] of Object.entries(settingDefaults)) {
  db.prepare("INSERT OR IGNORE INTO settings(key,value) VALUES(?,?)").run(key, value);
}

const adminEmail = process.env.ADMIN_EMAIL || "admin@mutungasworkshop.local";
const adminPassword = process.env.ADMIN_PASSWORD || "ChangeMe123!";
const existingAdmin = db.prepare("SELECT id FROM users WHERE role='admin' LIMIT 1").get();
if (!existingAdmin) {
  db.prepare("INSERT INTO users(name,email,password_hash,role) VALUES(?,?,?,?)")
    .run("Jospat Mutunga", adminEmail, bcrypt.hashSync(adminPassword, 10), "admin");
  console.log(`Admin created: ${adminEmail} / ${adminPassword}`);
}

const seedProducts = [
  ["agriculture","Maize","Fresh maize available from Mutunga's Workshop.","","",1],
  ["agriculture","Orange","Fresh oranges for customers and businesses.","","",1],
  ["agriculture","Lemon","Fresh lemons available when in season.","","",1],
  ["agriculture","Coconut","Fresh coconuts and coconut produce.","","",1],
  ["furniture","Tables","Strong wooden tables made for homes, shops and offices.","","",1],
  ["furniture","Chairs","Wooden chairs made for everyday use.","","",1],
  ["furniture","Beds","Wooden beds made in different sizes.","","",1],
  ["furniture","Cupboards","Wooden cupboards for storage.","","",1]
];
if (db.prepare("SELECT COUNT(*) AS c FROM products").get().c === 0) {
  const stmt = db.prepare("INSERT INTO products(category,name,description,price,image,available) VALUES(?,?,?,?,?,?)");
  for (const p of seedProducts) stmt.run(...p);
}
if (db.prepare("SELECT COUNT(*) AS c FROM services").get().c === 0) {
  db.prepare("INSERT INTO services(name,description,price) VALUES(?,?,?)")
    .run("Motorcycle Repair", "Motorcycle diagnosis, maintenance and repair services.", "");
}

const upload = multer({
  storage: multer.diskStorage({
    destination: path.join(__dirname, "public", "uploads"),
    filename: (_, file, cb) => {
      const safe = file.originalname.replace(/[^a-zA-Z0-9._-]/g, "_");
      cb(null, `${Date.now()}-${safe}`);
    }
  }),
  limits: { fileSize: 4 * 1024 * 1024 }
});

function requireLogin(req, res, next) {
  if (!req.session.user) return res.status(401).json({ error: "Please log in." });
  next();
}
function requireAdmin(req, res, next) {
  if (!req.session.user || req.session.user.role !== "admin")
    return res.status(403).json({ error: "Admin access required." });
  next();
}

app.get("/api/settings", (req,res) => {
  const rows = db.prepare("SELECT key,value FROM settings").all();
  res.json(Object.fromEntries(rows.map(r => [r.key, r.value])));
});

app.put("/api/settings", requireAdmin, (req,res) => {
  const allowed = Object.keys(settingDefaults);
  const update = db.prepare("INSERT INTO settings(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value");
  const transaction = db.transaction(data => {
    for (const key of allowed) if (typeof data[key] === "string") update.run(key, data[key]);
  });
  transaction(req.body);
  res.json({ ok: true });
});

app.get("/api/products", (req,res) => {
  res.json(db.prepare("SELECT * FROM products ORDER BY created_at DESC").all());
});

app.post("/api/products", requireAdmin, upload.single("image"), (req,res) => {
  const image = req.file ? `/uploads/${req.file.filename}` : "";
  const r = db.prepare("INSERT INTO products(category,name,description,price,image,available) VALUES(?,?,?,?,?,?)")
    .run(req.body.category, req.body.name, req.body.description || "", req.body.price || "", image, req.body.available === "0" ? 0 : 1);
  res.json({ id: r.lastInsertRowid });
});

app.put("/api/products/:id", requireAdmin, upload.single("image"), (req,res) => {
  const old = db.prepare("SELECT image FROM products WHERE id=?").get(req.params.id);
  const image = req.file ? `/uploads/${req.file.filename}` : (old?.image || "");
  db.prepare("UPDATE products SET category=?,name=?,description=?,price=?,image=?,available=? WHERE id=?")
    .run(req.body.category, req.body.name, req.body.description || "", req.body.price || "", image, req.body.available === "0" ? 0 : 1, req.params.id);
  res.json({ ok: true });
});

app.delete("/api/products/:id", requireAdmin, (req,res) => {
  db.prepare("DELETE FROM products WHERE id=?").run(req.params.id);
  res.json({ ok: true });
});

app.get("/api/services", (req,res) => res.json(db.prepare("SELECT * FROM services ORDER BY created_at DESC").all()));

app.post("/api/services", requireAdmin, upload.single("image"), (req,res) => {
  const image = req.file ? `/uploads/${req.file.filename}` : "";
  const r = db.prepare("INSERT INTO services(name,description,price,image) VALUES(?,?,?,?)")
    .run(req.body.name, req.body.description || "", req.body.price || "", image);
  res.json({ id: r.lastInsertRowid });
});

app.put("/api/services/:id", requireAdmin, upload.single("image"), (req,res) => {
  const old = db.prepare("SELECT image FROM services WHERE id=?").get(req.params.id);
  const image = req.file ? `/uploads/${req.file.filename}` : (old?.image || "");
  db.prepare("UPDATE services SET name=?,description=?,price=?,image=? WHERE id=?")
    .run(req.body.name, req.body.description || "", req.body.price || "", image, req.params.id);
  res.json({ ok: true });
});

app.delete("/api/services/:id", requireAdmin, (req,res) => {
  db.prepare("DELETE FROM services WHERE id=?").run(req.params.id);
  res.json({ ok: true });
});

app.post("/api/register", (req,res) => {
  const { name, email, password } = req.body;
  if (!name || !email || !password || password.length < 6)
    return res.status(400).json({ error: "Name, email and a password of at least 6 characters are required." });
  try {
    const hash = bcrypt.hashSync(password, 10);
    const r = db.prepare("INSERT INTO users(name,email,password_hash) VALUES(?,?,?)").run(name.trim(), email.toLowerCase().trim(), hash);
    req.session.user = { id: r.lastInsertRowid, name, email, role: "customer" };
    res.json({ user: req.session.user });
  } catch {
    res.status(400).json({ error: "That email is already registered." });
  }
});

app.post("/api/login", (req,res) => {
  const user = db.prepare("SELECT * FROM users WHERE email=?").get((req.body.email || "").toLowerCase().trim());
  if (!user || !bcrypt.compareSync(req.body.password || "", user.password_hash))
    return res.status(401).json({ error: "Invalid email or password." });
  req.session.user = { id: user.id, name: user.name, email: user.email, role: user.role };
  res.json({ user: req.session.user });
});

app.post("/api/logout", (req,res) => req.session.destroy(() => res.json({ ok: true })));
app.get("/api/me", (req,res) => res.json({ user: req.session.user || null }));

app.post("/api/inquiries", requireLogin, (req,res) => {
  const { product_id, service_id, message } = req.body;
  if (!message?.trim()) return res.status(400).json({ error: "Please enter your question." });
  const r = db.prepare("INSERT INTO inquiries(user_id,product_id,service_id,message) VALUES(?,?,?,?)")
    .run(req.session.user.id, product_id || null, service_id || null, message.trim());
  res.json({ id: r.lastInsertRowid });
});

app.get("/api/my-inquiries", requireLogin, (req,res) => {
  res.json(db.prepare(`
    SELECT i.*, p.name AS product_name, s.name AS service_name
    FROM inquiries i
    LEFT JOIN products p ON p.id=i.product_id
    LEFT JOIN services s ON s.id=i.service_id
    WHERE i.user_id=? ORDER BY i.created_at DESC
  `).all(req.session.user.id));
});

app.get("/api/admin/inquiries", requireAdmin, (req,res) => {
  res.json(db.prepare(`
    SELECT i.*, u.name AS customer_name, u.email AS customer_email,
           p.name AS product_name, s.name AS service_name
    FROM inquiries i
    JOIN users u ON u.id=i.user_id
    LEFT JOIN products p ON p.id=i.product_id
    LEFT JOIN services s ON s.id=i.service_id
    ORDER BY i.created_at DESC
  `).all());
});

app.put("/api/admin/inquiries/:id", requireAdmin, (req,res) => {
  db.prepare("UPDATE inquiries SET reply=?,status=? WHERE id=?")
    .run(req.body.reply || "", req.body.status || "replied", req.params.id);
  res.json({ ok: true });
});

app.get("/api/admin/customers", requireAdmin, (req,res) => {
  res.json(db.prepare("SELECT id,name,email,created_at FROM users WHERE role='customer' ORDER BY created_at DESC").all());
});

app.get("/admin", (req,res) => {
  res.sendFile(path.join(__dirname, "public", "admin.html"));
});

if (require.main === module) {
  app.listen(PORT, () => console.log(`Mutunga's Workshop running at http://localhost:${PORT}`));
}

module.exports = app;
