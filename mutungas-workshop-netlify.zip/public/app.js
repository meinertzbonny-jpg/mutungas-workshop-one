let products=[], services=[], me=null, settings={};

async function api(url, options={}) {
  const r=await fetch(url, options);
  const data=await r.json().catch(()=>({}));
  if(!r.ok) throw new Error(data.error || "Something went wrong");
  return data;
}
function esc(s=""){return String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[c]));}
function iconFor(name){const n=name.toLowerCase(); if(n.includes("maize"))return"🌽"; if(n.includes("orange"))return"🍊"; if(n.includes("lemon"))return"🍋"; if(n.includes("coconut"))return"🥥"; if(n.includes("table"))return"🪵"; if(n.includes("chair"))return"🪑"; if(n.includes("bed"))return"🛏️"; if(n.includes("cupboard"))return"🗄️"; return"🔧";}

function renderProducts(filter="agriculture"){
  const list=products.filter(p=>p.category===filter);
  document.querySelector("#productGrid").innerHTML=list.map(p=>`
  <article class="card">
    <div class="card-img">${p.image?`<img src="${p.image}" style="width:100%;height:100%;object-fit:cover">`:iconFor(p.name)}</div>
    <div class="card-body"><h3>${esc(p.name)}</h3><p>${esc(p.description)}</p>${p.price?`<p><strong>${esc(p.price)}</strong></p>`:""}<button class="ask" onclick="askProduct(${p.id})">Ask About This</button></div>
  </article>`).join("") || "<p>No products listed yet.</p>";
}
function renderServices(){
  document.querySelector("#serviceGrid").innerHTML=services.map(s=>`
  <article class="card"><div class="card-img">${s.image?`<img src="${s.image}" style="width:100%;height:100%;object-fit:cover">`:"🔧"}</div>
  <div class="card-body"><h3>${esc(s.name)}</h3><p>${esc(s.description)}</p>${s.price?`<p><strong>${esc(s.price)}</strong></p>`:""}<button class="ask" onclick="askService(${s.id})">Ask About This Service</button></div></article>`).join("");
}
function openModal(html){document.querySelector("#modalContent").innerHTML=html;document.querySelector("#modal").classList.remove("hidden")}
function closeModal(){document.querySelector("#modal").classList.add("hidden")}
async function askProduct(id){if(!me)return openAuth("Please create an account or log in before asking about a product."); const p=products.find(x=>x.id===id); inquiryForm("product",p)}
async function askService(id){if(!me)return openAuth("Please create an account or log in before asking about a service."); const s=services.find(x=>x.id===id); inquiryForm("service",s)}
function inquiryForm(type,item){
 openModal(`<h2>Ask about ${esc(item.name)}</h2><form onsubmit="sendInquiry(event,'${type}',${item.id})"><div class="field"><label>Your question</label><textarea id="inq" rows="5" placeholder="Write your question here..." required></textarea></div><button class="btn">Send Question</button></form>`);
}
async function sendInquiry(e,type,id){e.preventDefault();try{await api("/api/inquiries",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({product_id:type==="product"?id:null,service_id:type==="service"?id:null,message:document.querySelector("#inq").value})});closeModal();alert("Your question has been sent to Mutunga's Workshop.");}catch(e){alert(e.message)}}
function openAuth(note=""){
openModal(`<h2>Customer account</h2>${note?`<div class="notice">${esc(note)}</div>`:""}<div class="tabs"><button class="tab active" onclick="authTab('login')">Login</button><button class="tab" onclick="authTab('register')">Create Account</button></div><div id="authForm"></div>`);authTab("login");
}
function authTab(type){
document.querySelector("#authForm").innerHTML=type==="login"?`<form onsubmit="login(event)"><div class="field"><label>Email</label><input id="email" type="email" required></div><div class="field"><label>Password</label><input id="password" type="password" required></div><button class="btn">Login</button></form>`:`<form onsubmit="register(event)"><div class="field"><label>Name</label><input id="name" required></div><div class="field"><label>Email</label><input id="email" type="email" required></div><div class="field"><label>Password (6+ characters)</label><input id="password" type="password" minlength="6" required></div><button class="btn">Create Account</button></form>`;
}
async function login(e){e.preventDefault();try{const d=await api("/api/login",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({email:email.value,password:password.value})});me=d.user;closeModal();updateAccount()}catch(e){alert(e.message)}}
async function register(e){e.preventDefault();try{const d=await api("/api/register",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({name:name.value,email:email.value,password:password.value})});me=d.user;closeModal();updateAccount()}catch(e){alert(e.message)}}
function updateAccount(){document.querySelector("#accountBtn").textContent=me?`Hi, ${me.name}`:"Login";document.querySelector("#accountBtn").onclick=()=>me?openCustomer():openAuth()}
async function openCustomer(){const qs=await api("/api/my-inquiries");openModal(`<h2>My Account</h2><p>Welcome, ${esc(me.name)}.</p><button class="outline" onclick="logout()">Log out</button><h3 style="margin-top:25px">My Questions</h3>${qs.length?qs.map(q=>`<div class="notice"><strong>${esc(q.product_name||q.service_name||"Workshop")}</strong><br>${esc(q.message)}<br><small>${q.reply?`Reply: ${esc(q.reply)}`:"Waiting for a reply"}</small></div>`).join(""):"<p>You have not sent any questions yet.</p>"}`)}
async function logout(){await api("/api/logout",{method:"POST"});me=null;closeModal();updateAccount()}
async function init(){
 settings=await api("/api/settings"); products=await api("/api/products"); services=await api("/api/services"); const d=await api("/api/me");me=d.user;
 document.querySelector("#aboutText").textContent=settings.about; document.querySelector("#locationText").textContent=settings.location;
 document.querySelector("#contactLocation").textContent=settings.location; document.querySelector("#phone").textContent=settings.phone; document.querySelector("#whatsapp").textContent=settings.whatsapp; document.querySelector("#email").textContent=settings.email; if(document.querySelector("#hours"))document.querySelector("#hours").textContent=settings.hours||""; if(document.querySelector("#reachMe"))document.querySelector("#reachMe").textContent=settings.reach_me||""; document.querySelector("#year").textContent=new Date().getFullYear();
 renderProducts();renderServices();updateAccount();
 document.querySelectorAll(".tab").forEach(t=>t.addEventListener("click",()=>{document.querySelectorAll(".tab").forEach(x=>x.classList.remove("active"));t.classList.add("active");renderProducts(t.dataset.filter)}));
}
document.addEventListener("DOMContentLoaded",init);
