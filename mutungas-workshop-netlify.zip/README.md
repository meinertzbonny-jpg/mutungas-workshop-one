# Mutunga's Workshop

A starter full-stack website for:
- Agricultural products: maize, orange, lemon, coconut
- Furniture: tables, chairs, beds, cupboards
- Engineering: motorcycle repair and other services
- Customer registration/login and product/service questions
- Private admin dashboard
- Editable business information
- Add new crops, furniture and services from the admin dashboard

## Requirements
Node.js 18+ is recommended.

## Run locally

1. Open a terminal in this folder.
2. Run:
   npm install
3. Start:
   npm start
4. Open:
   http://localhost:3000

## Admin

The first run creates an admin account using:
- Email: admin@mutungasworkshop.local
- Password: ChangeMe123!

Open:
http://localhost:3000/admin

IMPORTANT: Change the admin password and session secret before deploying publicly. The starter uses environment variables:
ADMIN_EMAIL
ADMIN_PASSWORD
SESSION_SECRET

Example (PowerShell):
$env:ADMIN_EMAIL="your-email@example.com"
$env:ADMIN_PASSWORD="a-strong-password"
$env:SESSION_SECRET="a-long-random-secret"
npm start

## Contact details

The admin dashboard initially contains placeholders for phone, WhatsApp and email. Replace them from the dashboard.

## Production note

This is a functional starter, but before public deployment it should be hardened with HTTPS, a production session store, stronger account recovery/verification, rate limiting, backups, and a managed database if the site becomes busy.
